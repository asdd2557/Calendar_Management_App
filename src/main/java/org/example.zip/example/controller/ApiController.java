package org.example.controller;

import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.example.dto.ScheduleRequestDTO;
import org.example.entity.Schedule;
import org.example.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class ApiController {
    private final ScheduleService scheduleService;

    @PostMapping
    public Schedule createSchedule(@RequestBody Schedule schedule) {
        return scheduleService.saveSchedule(schedule);
    }

    // 일정 수정
    @PutMapping("/{id}")
    public ScheduleRequestDTO updateSchedule(
            @PathVariable Long id,
            @RequestBody ScheduleRequestDTO scheduleRequestDTO,
            @RequestParam String password // 비밀번호를 쿼리 파라미터로 전달
    ) {
        return scheduleService.updateSchedule(id, scheduleRequestDTO, password);
    }

    @DeleteMapping("/{id}")
    public void deleteSchedule(@PathVariable Long id) {
        scheduleService.deleteSchedule(id);
    }

    @DeleteMapping("/all")
    public void allDeleteSchedule() {
        scheduleService.allDeleteSchedule();
    }
    @GetMapping
    public List<ScheduleRequestDTO> getSchedules(
            @RequestParam(required = false) String startDateTime,
            @RequestParam(required = false) String endDateTime,
            @RequestParam(required = false) String userName
    ) {
        LocalDateTime startDate = null;
        LocalDateTime endDate = null;

        try {
            // 파라미터 유효성 검사 및 공백 제거
            if (startDateTime != null && !startDateTime.trim().isEmpty()) {
                startDate = LocalDateTime.parse(startDateTime.trim());
            }

            if (endDateTime != null && !endDateTime.trim().isEmpty()) {
                endDate = LocalDateTime.parse(endDateTime.trim());
            }
        } catch (DateTimeParseException e) {
            // 잘못된 날짜 형식 처리
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date format: " + e.getParsedString());
        }

        // 서비스 호출
        return scheduleService.getSchedulesByPeriod(startDate, endDate, userName);
    }


}
