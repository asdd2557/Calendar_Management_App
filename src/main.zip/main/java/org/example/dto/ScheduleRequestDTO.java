package org.example.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScheduleRequestDTO {
    private String title;
    private String description;
    private String startDateTime;
    private String endDateTime;
}
